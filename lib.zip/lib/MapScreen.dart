import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class MapScreen extends StatefulWidget {
  final Position userLocation;
  const MapScreen({Key? key, required this.userLocation}) : super(key: key);

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  Location _location = Location();
  LatLng _initialPosition = LatLng(28.6139, 77.2090); // Default to Delhi, India
  late Stream<LocationData> _locationStream;
  List<Marker> _markers = [];

  // Replace with your actual Google Maps API key
  final String _googleApiKey = 'AIzaSyAbBqiZ1L2UHiZhLGWxdaSPXHGSeuK23p8';

  @override
  void initState() {
    super.initState();
    _getUserLocation();
    _locationStream = _location.onLocationChanged;
  }

  Future<void> _getUserLocation() async {
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;

    _serviceEnabled = await _location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await _location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await _location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await _location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    final _currentLocation = await _location.getLocation();
    setState(() {
      _initialPosition = LatLng(_currentLocation.latitude!, _currentLocation.longitude!);
    });

    _fetchNearbyPoliceStations(_initialPosition);
  }

  // Fetch nearby police stations using Google Places API
  Future<void> _fetchNearbyPoliceStations(LatLng position) async {
    final String url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${position.latitude},${position.longitude}&radius=5000&type=police&key=$_googleApiKey';

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      if (data['status'] == 'OK') {
        List<Marker> markers = [];

        for (var result in data['results']) {
          final LatLng markerPosition = LatLng(
            result['geometry']['location']['lat'],
            result['geometry']['location']['lng'],
          );

          markers.add(
            Marker(
              markerId: MarkerId(result['place_id']),
              position: markerPosition,
              infoWindow: InfoWindow(
                title: result['name'],
                snippet: result['vicinity'],
              ),
            ),
          );
        }

        setState(() {
          _markers = markers;
        });
      } else {
        print('Error fetching police stations: ${data['status']}');
      }
    } else {
      print('Failed to fetch police stations. Status code: ${response.statusCode}');
    }
  }

  void _onLocationChanged(LocationData locationData) {
    final LatLng newPosition = LatLng(locationData.latitude!, locationData.longitude!);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        _initialPosition = newPosition;
      });

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newLatLng(newPosition),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<LocationData>(
        stream: _locationStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasData) {
            final locationData = snapshot.data!;
            _onLocationChanged(locationData);
          }

          return GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _initialPosition,
              zoom: 14.0,
            ),
            onMapCreated: (GoogleMapController controller) {
              _mapController = controller;
            },
            markers: Set<Marker>.of(_markers),
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
          );
        },
      ),
    );
  }
}
